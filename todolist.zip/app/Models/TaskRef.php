<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TaskRef extends Model {

    public $timestamps = false;
    
    protected $table = 'TASK_REF';

}