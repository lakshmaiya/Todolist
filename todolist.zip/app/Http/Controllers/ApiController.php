<?php

namespace App\Http\Controllers;
use App\Http\Requests\AddUserRequest;
use Illuminate\Http\Request;;
use App\User;
use App\Models\TaskRef;
use App\Models\MyToDoList;
use Illuminate\Http\Response;

class ApiController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
    * Add User.
    *
    * @return \Illuminate\Http\Response
    */

   public function createUser(AddUserRequest $request) {

        $this->validate($request, [
            'title' => 'required|unique:posts|max:255',
            'body' => 'required',
        ]);

        $user_info = ['USER_NAME'     => $request->get('user_name'),
                    'PASSWORD'      => bcrypt($request->get('password')),
                    'EMAIL'         => $request->get('email'),
                    'PERMISSIONS'   => $request->get('permissions'),
                    'CREATE_DATE'   => date('Y-m-d H:i:s'),
                    'UPDATE_DATE'   => date('Y-m-d H:i:s')
                  ];

      $user_id = User::insertGetId($student_info);

      if($user_id) {

          $response['success'] = true;
          $response['msg'] = 'Great! User has been added successfully';

      } else {

          $response['success'] = false;
          $response['msg'] = 'oops! Failed to add user, please try later';

      }

      return Response::json($response);
   }

   /**
    * Create Task.
    *
    * @return \Illuminate\Http\Response
    */

   public function createTask(Request $request) {

        $todays_date = date('Y-m-d H:i:s');

        $this->validate($request, [
            'task_name' => 'required|max:255',
            'user_id' => 'required|integer',
            'description' => 'required',
        ]);

        $task_info = ['TASK_NAME'   => $request->get('task_name'),
                    'TASK_DES'      => $request->get('description'),
                    'CREATE_DATE'   => $todays_date,
                    'UPDATED_DATE'  => $todays_date
                  ];

      $task_id = TaskRef::insertGetId($task_info);

      if($task_id) {

            //store todo user's list
            $todo_info = ['LIST_NAME'  => $request->get('list_name'),
                          'TASK_ID'    => $task_id,
                          'USER_ID'    => $request->get('user_id'),
                          'START_DATE' => $request->get('start_date'),
                          'END_DATE'   => $request->get('end_date'),
                          'CREATE_DATE'=> $todays_date,
                          'UPDATED_DATE'=> $todays_date
                        ];
            
            MyToDoList::insert($todo_info);

          $response['success'] = true;
          $response['msg'] = 'Great! Task has been added successfully';

      } else {

          $response['success'] = false;
          $response['msg'] = 'oops! Failed to create task, please try later';

      }

      return response()->json($response);
   }

   /**
    * Get Task List.
    *
    * @return \Illuminate\Http\Response
    */

   public function getTaskList(Request $request) {

        $this->validate($request, [
            'user_id' => 'required|integer',
        ]);

        $page_no = ($request->get('page_no')) ? $request->get('page_no') : 1;
        $user_id = $request->get('user_id');

      $total_rec = 2;

      $offset = ($page_no - 1) * $total_rec;

      $task_list = MyToDoList::join('TASK_REF AS TR', 'TR.TASK_ID', '=', 'MY_TODO_LIST.TASK_ID')
                   ->where(['USER_ID' => $user_id])->skip($offset)->take($total_rec)->get();

      if(count($task_list)) {

          $response['success'] = true;
          $response['data'] = $task_list;
          $response['msg'] = 'Task list';

      } else {

          $response['success'] = false;
          $response['msg'] = 'Oops! No record found';

      }

      return response()->json($response);
   }

   /**
    * Get Task Status.
    *
    * @return \Illuminate\Http\Response
    */

   public function getTaskStatus(Request $request) {

        $this->validate($request, [
            'user_id' => 'required|integer',
            'task_id' => 'required|integer',
        ]);

        $user_id = $request->get('user_id');
        $task_id = $request->get('task_id');

        $task_status = MyToDoList::join('STATUS', 'STATUS.STATUS_CD', '=', 'MY_TODO_LIST.STATUS_CD')
                   ->where(['USER_ID' => $user_id, 'TASK_ID' => $task_id])
                   ->get(['TASK_ID','STSTUS_DESC']);

        if(count($task_status)) {

          $response['success'] = true;
          $response['data'] = $task_status;
          $response['msg'] = 'Task status';

        } else {

          $response['success'] = false;
          $response['msg'] = 'Oops! No record found';

        }

      return response()->json($response);
   }


   /**
    * Update Task Status.
    *
    * @return \Illuminate\Http\Response
    */

   public function updateTaskStatus(Request $request) {

        $todays_date = date('Y-m-d H:i:s');

        $this->validate($request, [
            'task_id' => 'required|max:255',
            'user_id' => 'required|integer',
            'status' => 'required|in:NOT-STARTED,STARTED,IN-PROGRESS,CANCELED,COMPLETE',
        ]);

        $user_id = $request->get('user_id');
        $task_id = $request->get('task_id');

        $task_status = ['STATUS_CD'     => $request->get('status'),
                        'UPDATED_DATE'  => $todays_date
                    ];

      $task_id = MyToDoList::where(['USER_ID' => $user_id, 'TASK_ID' => $task_id])->update($task_status);

      if($task_id) {

          $response['success'] = true;
          $response['msg'] = 'Great! Task status updated successfully';

      } else {

          $response['success'] = false;
          $response['msg'] = 'Oops! Failed to update task status, please try later';

      }

      return response()->json($response);
   }
}
