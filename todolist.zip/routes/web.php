<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->post('/create-user', 'ApiController@createUser');
$router->post('/create-task', 'ApiController@createTask');
$router->get('/get-task-list', 'ApiController@getTaskList');
$router->get('/get-task-status', 'ApiController@getTaskStatus');
$router->post('/update-task-satus', 'ApiController@updateTaskStatus');
